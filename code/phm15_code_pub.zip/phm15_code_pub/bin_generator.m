function [ bins, num_features ] = bin_generator(data_a, steps)

%%  generate the bins for histograms
%   input:
%       data_a: raw data 
%       steps:  stpes of each dimension, control the number of bins of each
%               dimension
%   output:
%       bins:           cell array of bins of each dimension
%       num_features:   total nujmber of features

% default
% steps = [6, 8, 1, 9, 1, 1, 1, 1];

nfeatures = size(data_a, 2);

bins = cell(nfeatures, 1);
num_features = 0;
for i = 1:nfeatures
    cur_bins = sort(unique(data_a(:, i)));
    bins{i} = cur_bins(1:steps(i):end);
    num_features = num_features + length(bins{i});
end


end