function [y_selector] = yfilter(y_c)

%%  convert fault labels to binary indicators, each dimension represents a class
%   input:
%       y_c:    cell array of column vectors, each vector is an array of
%               labels
%   output:
%       y_selector: binary indicators of each class

nfiles = length(y_c);
y_selector = zeros(nfiles, 6);
for i = 1:nfiles
    y_selector(i, unique(y_c{i})) = 1;
end

y_selector = y_selector(:, 1:5);

end