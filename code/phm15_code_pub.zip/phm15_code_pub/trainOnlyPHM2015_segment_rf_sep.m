function [ model ] = trainOnlyPHM2015_segment_rf_sep(data, y)

%%  train classifiers
%   input:
%       data:   cell array of training data, each cell is a plant
%       y:      cell array of labels of trainging data
%   output:
%       model: cell array of classifiers of plants

disp('training');

% ntrees = round(4*size(data, 2));
ntrees = 256;

nfiles = length(data);
model = cell(nfiles, 1);
matlabpool local 4
parfor i = 1:nfiles
    % random forest
%     model{i} = classRF_train(data{i}, y{i}, ntrees);
    % GDBT
    model{i} = fitensemble(data{i}, y{i}, 'RUSBoost', ntrees, 'Tree');
end
matlabpool close

disp('training finished');

end