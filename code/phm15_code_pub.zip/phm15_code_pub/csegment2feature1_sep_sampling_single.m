function [cur_feature, cur_timestamp] = csegment2feature1_sep_sampling_single(csegment, bins, nfeatures)

%%  extract features from time segments
%   input:
%       csegment:   cell array of time segments of plants
%       bins:       bins of histograms
%       nfeatures:  total number of features
%   output:
%       cur_feature:    cell array of features of plants
%       cur_timestamp:  cell array of start/end time of segments
    
nsegments = size(csegment, 1);
cur_feature = zeros(nsegments, nfeatures);
cur_timestamp = zeros(nsegments, size(csegment{1, 2}, 2));
for j = 1:nsegments
    segment_feature = csegment{j, 1};
    feature_idx = 1;
    for k = 1:8
        cur_feature_tmp = histc(segment_feature(:, k), bins{k});
        sum_cur_feature_tmp = sum(cur_feature_tmp);
        if sum_cur_feature_tmp ~= 0
            cur_feature_tmp = cur_feature_tmp / sum(cur_feature_tmp);
        end
        cur_feature(j, feature_idx:(feature_idx+length(bins{k})-1)) = cur_feature_tmp;
        feature_idx = feature_idx + length(bins{k});
    end
    cur_timestamp(j, :) = csegment{j, 2};
end
    

end