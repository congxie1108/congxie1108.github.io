function [ time_c_hat_r, y_c_hat_r ] = remove_duplicate(time_c, y_c, time_c_hat, y_c_hat)

%%  remove the fault events already in the test files
%   input:
%       time_c:     true start/end time of fault events
%       y_c:        true labels of fault events
%       time_c_hat: predicted start/end time of fault events
%       y_c_hat:    predicted labels of fault events
%   output:
%       time_c_hat_r: filtered predicted start/end time of fault events
%       y_c_hat_r:    filtered predicted labels of fault events

% threshold within which the time of an event is correct
threshold = datenum('2014-08-25 10:00', 'yyyy-mm-dd HH:MM')-datenum('2014-08-25 09:00', 'yyyy-mm-dd HH:MM');

% flag of each fault event indicating whether it is detected
detectedFlag = zeros(length(y_c), 1);
time_c_hat_r = [];
y_c_hat_r = [];

ncorrect = 0;
for i = 1:length(y_c_hat)
    hat_detectedFlag = 0;
    matchFlag = 0;
    
    for j = 1:length(y_c)
        % if start/end time is correct
        if abs(time_c_hat(i, 1)-time_c(j, 1))<=threshold && abs(time_c_hat(i, 2)-time_c(j, 2))<=threshold
            detectedFlag(j) = 1;
            hat_detectedFlag = 1;
            % if fault label is correct
            if y_c_hat(i) == y_c(j)
                matchFlag = 1;
                ncorrect = ncorrect+1;
                break; 
            end
        end
    end
    
    if matchFlag == 0 && hat_detectedFlag == 0
        time_c_hat_r = [time_c_hat_r; time_c_hat(i, :)];
        y_c_hat_r = [y_c_hat_r; y_c_hat(i)];
    end
end

end