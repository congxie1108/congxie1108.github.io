% load the bins of histograms
load('hist_file.mat');
% read dataset
tic;[train_features, train_labels, test_dataseq_cell, test_timeseq_cell, test_time_c, test_y_c] = readPHM2015Data_global_traintestseq_csegment_feature([1, 3:15, 17, 18, 21, 23, 24, 25, 27:36, 39, 40], [1, 4, 8], bins, nfeatures);toc;
% train models
tic;[ segment_model ] = trainOnlyPHM2015_segment_rf_sep(train_features, train_labels);toc;
% scoring
validateOnlyPHM2015_segment_rf_sep_testseq(test_dataseq_cell, test_timeseq_cell, test_time_c, test_y_c, segment_model, bins, nfeatures);
