1. Run config.m to install the dependency.

2. Matlab 2014 is needed.

3. Run test_segment_train_validate2.m