function [ score ] = validateOnlyPHM2015_segment_rf_sep_testseq(test_dataseq_cell, test_timeseq_cell, time_c, y_c, model, bins, nfeatures)

%%  predict the fault events in the testing data and compute the score
%   input:
%       test_dataseq_cell:  cell array of raw data of each plant
%       test_timeseq_cell:  cell array of time stamps of the correspongding
%                           elements in test_dataseq_cell
%       time_c:             cell array of time of fault events
%       y_c:                cell array of labels of fault events
%       model:              cell array of predictive models of the plants
%       bins:               bins for the histograms
%       nfeatures:          total number of features
%   output:
%       score:  total score of all the plants

% note: y is a one-column vector
% seperate outlier:6 and target:1,2,3,4,5

disp('testing');

% initialization
score = 0;
total_score = 0;
total_ncorrect = 0;
total_nfalsealarm = 0;
% length of time pieces, default is 15 min
time_piece = 0.0104;
% number of time pieces in a segment
piece_seg1 = 1;
recall_array = zeros(length(y_c), 1);
score_array = zeros(length(y_c), 1);
result_array = zeros(length(y_c), 4);

matlabpool local 4
parfor i = 1:length(y_c)
    
    %% predict round 1
    % filter the data without faults
    tmp_timea = test_timeseq_cell{i};
    feature_a = test_dataseq_cell{i};
    j = 1;
    cur_segment = cell(1, 2);
    cur_segment_step_idx = 1;
    % enumerate time segments
    while j <= length(tmp_timea)
        jj = j;
        next_j = j+1;
        for k = piece_seg1
            time_threshold = time_piece * k + 0.0014;
            prev_jj = jj;
            while jj+1 <= length(tmp_timea) && tmp_timea(jj+1)-tmp_timea(j) <= time_threshold
                jj = jj+1;
            end
            if k == 0 || jj ~= prev_jj
                cur_segment{cur_segment_step_idx, 1} = feature_a(j:jj, :);
                cur_segment{cur_segment_step_idx, 2} = [j, jj];
                cur_segment_step_idx = cur_segment_step_idx+1;
            end
            next_j = jj+1;
            if jj == prev_jj
                break;
            end
        end
        j = next_j;
    end
    % extract features
    [cur_feature, cur_range] = csegment2feature1_sep_sampling_single(cur_segment, bins, nfeatures);
%     clear cur_segment;
    % random forest
%     y_c_hat0 = classRF_predict(cur_feature, model{i});
    % GDBT
    y_c_hat0 = predict(model{i}, cur_feature);
    seq_filter = ones(length(tmp_timea), 1);
    for j = 1:length(y_c_hat0)
        if y_c_hat0(j) == 6
            seq_filter(cur_range(j, 1):cur_range(j, 2)) = 0;
        end
    end
    tmp_timea = tmp_timea(seq_filter==1);
    feature_a = feature_a(seq_filter==1, :);
    % predict round 1 end
    
    
    %% predict round 2
    segment_length_filter = zeros(80, 1);
    segment_length_filter([1, 4, 8]) = 1;
    % enumerate time segments
    cur_segment_idx = 1;
    j = 1;
    cur_segment = cell(0);
    while j <= length(tmp_timea)
        jj = j;
        next_j = j+1;
        
        for k = 0:10
            time_threshold = time_piece * k + 0.0014;
            prev_jj = jj;
            while jj+1 <= length(tmp_timea) && tmp_timea(jj+1)-tmp_timea(j) <= time_threshold
                jj = jj+1;
            end
            if k ~= 0 && jj ~= prev_jj
                if segment_length_filter(k)==1
                    cur_segment{cur_segment_idx, 1} = feature_a(j:jj, :);
                    cur_segment{cur_segment_idx, 2} = [tmp_timea(j), tmp_timea(jj)];
                    cur_segment_idx = cur_segment_idx+1;
                end
            end
            if k == 0
                next_j = jj+1;
            end
            if jj == prev_jj
                break;
            end
        end
        j = next_j;
    end
    
    ncorrect = 0;
    nfalsealarm = 0;
    if length(cur_segment) ~= 0
        [cur_feature, cur_time] = csegment2feature1_sep_sampling_single(cur_segment, bins, nfeatures);
%         clear cur_segment;
        % random forest
%         y_c_hat1 = classRF_predict(cur_feature, model{i});
        % GDBT
        y_c_hat1 = predict(model{i}, cur_feature);
        % predict round 2 end
        
        time_c_hat = cur_time;
        y_c_hat = y_c_hat1;
        
        %% connect the neighbouring fault events
        % remove the fault events totally contained in longer fault events
        [~, sorted_idx] = sort(time_c_hat(:, 1));
        time_c_hat = time_c_hat(sorted_idx, :);
        y_c_hat = y_c_hat(sorted_idx, :);
        y_c_hat1 = y_c_hat1(sorted_idx, :);
        for j = 2:length(y_c_hat1)
            if y_c_hat1(j) ~=6 && y_c_hat1(j) == y_c_hat1(j-1) && time_c_hat(j, 1) == time_c_hat(j-1, 1) && time_c_hat(j, 2) >= time_c_hat(j-1, 2)
                y_c_hat(j-1) = 6;
            end
        end
        % remove the fault events totally contained in longer fault events
        [~, sorted_idx] = sort(time_c_hat(:, 2));
        time_c_hat = time_c_hat(sorted_idx, :);
        y_c_hat = y_c_hat(sorted_idx, :);
        y_c_hat1 = y_c_hat1(sorted_idx, :);
        for j = 2:length(y_c_hat1)
            if y_c_hat1(j) ~=6 && y_c_hat1(j) == y_c_hat1(j-1) && time_c_hat(j, 2) == time_c_hat(j-1, 2) && time_c_hat(j, 1) >= time_c_hat(j-1, 1)
                y_c_hat(j) = 6;
            end
        end
        
%        % connect the neighbouring fault events
%         [~, sorted_idx] = sort(time_c_hat(:, 2));
%         time_c_hat = time_c_hat(sorted_idx, :);
%         y_c_hat = y_c_hat(sorted_idx, :);
%         time_c_hat1 = time_c_hat;
%         y_c_hat1 = y_c_hat;
%         for j = 1:length(y_c_hat1)
%             if y_c_hat1(j) == 6
%                 continue;
%             end
%             for jj = (j+1):length(y_c_hat1)
%                 if y_c_hat1(jj) == 6
%                     continue;
%                 end
%                 if y_c_hat1(j) == y_c_hat1(jj) && time_c_hat1(j, 1) <= time_c_hat1(jj, 1) && time_c_hat1(j, 2) >= time_c_hat1(jj, 1)
%                     y_c_hat1(j) = 6;
%                     time_c_hat1(jj, 1) = time_c_hat1(j, 1);
%                 end
%             end
%         end
%         time_c_hat = time_c_hat1;
%         y_c_hat = y_c_hat1;
%         [~, sorted_idx] = sort(time_c_hat(:, 2));
%         time_c_hat = time_c_hat(sorted_idx, :);
%         y_c_hat = y_c_hat(sorted_idx, :);
        
        time_c_hat = time_c_hat(y_c_hat~=6, :);
        y_c_hat = y_c_hat(y_c_hat~=6, :);
        
        [cur_score, ncorrect, nfalsealarm, nmisclass, nmisalarm] = computeScore(time_c{i}, y_c{i}, time_c_hat, y_c_hat);
        result_array(i, :) = [ncorrect, nfalsealarm, nmisclass, nmisalarm];
    else
        cur_score = 0;
    end
        
    % compute the score
    fprintf('score: %f\n', cur_score);
    score = score + cur_score;
    total_score = total_score + 10*length(find(y_c{i}~=6));
    total_ncorrect = total_ncorrect+ncorrect;
    total_nfalsealarm = total_nfalsealarm+nfalsealarm;
    cur_time_c = time_c{i};
    recall_array(i) = ncorrect / length(find(y_c{i}~=6&(cur_time_c(:,2)-cur_time_c(:,1))<=12*0.0104));
    score_array(i) = cur_score;
    
    
end
matlabpool close
fprintf('total score: %f, full score: %f\n', score, total_score);
fprintf('correct: %d, false alarm: %d \n', total_ncorrect, total_nfalsealarm);

save('recall_array', 'recall_array');
save('score_array', 'score_array');

% write the results into a text file
fid = fopen('result.txt', 'w');
for i = 1:length(y_c)
    fprintf(fid, '%d, %d, %d, %d, %d \n', i, result_array(i, 1), result_array(i, 2), result_array(i, 3), result_array(i, 4));
end
fclose(fid);

disp('testing finished');

end