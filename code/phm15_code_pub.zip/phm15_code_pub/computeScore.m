function [ score, ncorrect, nfalsealarm, nmisclass, nmisalarm ] = computeScore(time_c, y_c, time_c_hat, y_c_hat)
%%  compute the score according to the official scoring rules
%   input:
%       time_c:     true start/end time of fault events
%       y_c:        true labels of fault events
%       time_c_hat: predicted start/end time of fault events
%       y_c_hat:    predicted labels of fault events
%   output:
%       score:          total score of all the events
%       ncorrect:       total number of correctly predicted events
%       nfalsealarm:    number of events incorrectly alarmed
%       nmisclass:      number of fault events with incorrect predictive
%                       labels
%       nmisalarm:      number of fault events not detected

% threshold within which the time of an event is correct
threshold = datenum('2014-08-25 10:00', 'yyyy-mm-dd HH:MM')-datenum('2014-08-25 09:00', 'yyyy-mm-dd HH:MM');

% flag of each fault event indicating whether it is detected
detectedFlag = zeros(length(y_c), 1);

% initialization
score = 0;
ncorrect = 0;
nmisclass = 0;
nfalsealarm = 0;
% flag of false alarm
falsealarm_array = zeros(length(y_c_hat), 1);
% flag of correctly matched, including fault label and time
matched_array = zeros(length(y_c), 1);

% scoring
for i = 1:length(y_c_hat)
    hat_detectedFlag = 0;
    matchFlag = 0;
    
    for j = 1:length(y_c)
        % ignore fault label 6
        if y_c(j) == 6
            continue;
        end
        
        % if start/end time is correct
        if abs(time_c_hat(i, 1)-time_c(j, 1))<=threshold && abs(time_c_hat(i, 2)-time_c(j, 2))<=threshold
            detectedFlag(j) = 1;
            hat_detectedFlag = 1;
            % if fault label is correct
            if y_c_hat(i) == y_c(j) && matched_array(j) == 0
                score = score+10;
                matchFlag = 1;
                ncorrect = ncorrect+1;
                matched_array(j) = 1;
                break; 
            end
            
        end
    end
    if hat_detectedFlag == 0
        score = score-0.1;
        nfalsealarm = nfalsealarm+1;
        falsealarm_array(i) = 1;
        
    elseif matchFlag == 0
        score = score-0.01;
        nmisclass = nmisclass+1;
    end
end

score = score - length(find(detectedFlag==0 & y_c~=6)) *0.1;
nmisalarm = length(find(detectedFlag==0 & y_c~=6));

fprintf('correct: %d, miss classification: %d, false alarm: %d, missed alarm: %d \n', ncorrect, nmisclass, nfalsealarm, nmisalarm);
fprintf('total score: %f, full score: %f\n', score, sum(y_c~=6)*10);

end