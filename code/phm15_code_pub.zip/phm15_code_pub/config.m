% configuration

% install the Random Forest package
addpath('randomforest-matlab/RF_Class_C/');
